# Task: go live with the EasyTime Pro → ESS bridge on this VPN machine

You are Claude Code running on the **VPN machine**. This handoff comes from a session on another PC
(session `4b29e270-4569-481b-b45d-29b24eb363f8`). On that PC the code was written and tested
against a mock EasyTime only. Real EasyTime Pro is reachable **only over the VPN**, so finishing the
job is your task here.

## Context

- **ESS** is the Champ HR employee self-service portal at `https://champ-hr.com` (Railway, behind
  Cloudflare).
  - Repo: https://github.com/developer00777/ESS
  - The work is **PR #1**, branch `easytime-chrome-bridge`: https://github.com/developer00777/ESS/pull/1
- **EasyTime Pro 9.0.6** (ZKTeco biometric attendance) runs on the office network, reachable through
  the VPN. While logged in, `GET <easytime>/iclock/api/transactions/?page_size=2` returns JSON
  (confirmed by the user).
- **The bridge** is a Chrome extension in `easytime-bridge/` (this folder).
  - It runs in one dedicated Chrome profile, reads EasyTime with the browser's existing login, and
    POSTs JSON to `https://champ-hr.com/api/attendance/easytime-import` using an import token.
  - Read `easytime-bridge/README.md`; its *Go-live checklist* is the definition of done.
- **The import token** is the value of the `EASYTIME_IMPORT_TOKEN` variable on the Railway app service.
  It is registered in ESS the first time it is used.

## Rules

- **Never ask for, print, store or echo passwords or the import token.**
  - The user types the token straight into the extension's settings.
  - If you need it for a command, have the user set it in their own shell:
    `$env:ESS_TOKEN = Read-Host -AsSecureString | ConvertFrom-SecureString -AsPlainText`.
    Reference it only as `$env:ESS_TOKEN`.
- **Never send requests to EasyTime with credentials, and never log in to EasyTime yourself.** The user
  does all EasyTime logins in Chrome.
- **Do not POST test punches to production ESS.** Read-only `GET` checks only.
- **Do not change the production database or Railway settings.** Tell the user what to change instead.
- You cannot click inside Chrome. Give the user exact click-steps for browser work, then ask them to
  paste back the text the extension shows.
- **If the extension code needs a fix:** edit it in `C:\Users\Harshil.K\easytime-bridge`, have the user click
  the reload icon on `chrome://extensions`, and keep a list of every change. Those changes must go back
  into PR #1 later (`integrations/easytime-bridge/` in the repo).

## Steps

### 0. Prerequisites — ask the user

1. Is PR #1 merged and deployed? Check this yourself:
   ```powershell
   curl.exe -s -w " [%{http_code}]" https://champ-hr.com/api/attendance/easytime-import
   ```
   - `401 invalid or missing token` → deployed.
   - `405` → not deployed yet. Steps 1–3 can still be done, but stop before step 4.
2. Is `EASYTIME_IMPORT_TOKEN` set on the Railway **app** service? It must be at least 32 characters.
   Generate it with
   `node -e "console.log(require('crypto').randomBytes(32).toString('base64url'))"`.
   The user saves it in a password manager.
3. What is the EasyTime Pro address, exactly as opened in the browser (with the port)?

### 1. Preflight (you run these)

- **Chrome version.** It must be ≥ 144.
  ```powershell
  (Get-Item "C:\Program Files\Google\Chrome\Application\chrome.exe").VersionInfo.ProductVersion
  ```
- **EasyTime is reachable through the VPN.**
  ```powershell
  curl.exe -s -o NUL -w "%{http_code}" --max-time 15 "<easytime>/iclock/api/transactions/?page_size=1"
  ```
  - `302`, `401` or `403` → reachable (it wants a login, which is expected).
  - `000` or a timeout → the VPN is down or the address is wrong.
- **ESS is reachable while the VPN is connected.**
  ```powershell
  curl.exe -s -o NUL -w "%{http_code}" --max-time 15 https://champ-hr.com/login
  ```
  - `200` → good.
  - Anything else means the VPN is routing all traffic and blocking it. The user must ask IT to
    allow `champ-hr.com`.

### 2. Put the extension in a permanent place

The folder must live at `C:\Users\Harshil.K\easytime-bridge`. Chrome loads it from there on every start, so it
must never be moved or deleted. If this handoff was extracted somewhere else, copy the folder there.

### 3. User does in Chrome (give them these steps)

1. Create a dedicated Chrome profile, e.g. "ESS bridge".
2. In that profile, log in to EasyTime Pro, ideally with a read-only user.
3. Open `chrome://extensions`, switch on **Developer mode** (it must stay on), click
   **Load unpacked**, pick `C:\Users\Harshil.K\easytime-bridge`, and pin the icon.
4. Turn on Chrome Settings → System → **Continue running background apps when Google Chrome is
   closed**.

### 4. Configure and test (user clicks, you interpret)

1. Open the extension's **Settings** and fill in:
   - EasyTime address;
   - ESS `https://champ-hr.com`;
   - the token.
   Click **Save** and allow access.
2. Click **Test EasyTime**. The expected output includes:
   - *answered with data*;
   - *Date filter: works*;
   - *Newest-first by id: yes*. "no" is acceptable: the bridge falls back to time windows.

   If it says *Date filter: IGNORED*, or shows an error, see Troubleshooting.
3. Click **Test ESS**. Expect *ESS accepted the token "Railway variable EASYTIME_IMPORT_TOKEN"*.

### 5. First sync and verification

1. The first sync starts within seconds and reads back 7 days. Within a few minutes the popup should
   say *Up to date*.
2. **Device feed check.** In ESS (HR admin login), open Admin Controls → Biometric → **Device feed**.
   Batches should be listed with *Applied* counts. You can also check from the shell, if the user
   has set `$env:ESS_TOKEN`:
   ```powershell
   curl.exe -s -H "Authorization: Bearer $env:ESS_TOKEN" https://champ-hr.com/api/attendance/easytime-import
   ```
   Expect a recent `lastImport` and a `latestPunchAt`.
3. **Unknown codes.** If the popup lists unknown employee codes, the user fixes those codes on the
   employees' ESS profiles, then uses **Re-send dates**.
4. **Spot-check.** Compare one employee's day in ESS with what EasyTime shows for that day.
5. **Recovery.**
   - Disconnect the VPN → the badge turns red within one sync interval (5 min). Reconnect → it clears.
   - Log out of EasyTime → the badge turns amber. Log back in → it clears.
6. **Keep it running.** The PC must not sleep. Ideally the VPN auto-reconnects.

### 6. Report back

Write `C:\Users\Harshil.K\GO-LIVE-REPORT.md` covering:
- each check and its result;
- any code changes, with a diff;
- anything still open.

Never include tokens or passwords in it. The user will bring this report to the original session.

## Troubleshooting

| What the extension says | Meaning / fix |
|---|---|
| Log in to EasyTime Pro in this Chrome profile | The session expired. The user logs in again in that profile |
| EasyTime Pro is not reachable … check the VPN | VPN down or wrong address; rerun the step-1 checks |
| not allowed to read transactions (403) | The EasyTime user lacks rights to Attendance → Transactions |
| Unexpected reply from /iclock/api/transactions/ | 9.0.6 answers in a different format. Ask the user to open `<easytime>/iclock/api/transactions/?page_size=2&ordering=-id` in the bridge profile and paste the JSON with names blanked. Adapt `page()` in `easytime.js` |
| Date filter: IGNORED | 9.0.6 uses different filter names. Find the right ones with the user (e.g. via the transactions screen's network requests in DevTools) and adjust `probe()` and the `start_time`/`end_time` usage in `sync.js` |
| ESS rejected the import token | Wrong value pasted, the variable is not set or is under 32 characters, or the token row was revoked |
| ESS answered HTTP 405 | PR #1 is not deployed yet |
| ESS is not reachable | A full-tunnel VPN is blocking the internet; IT must allow champ-hr.com |

## Local testing without real EasyTime

`easytime-bridge/dev/mock-easytime.mjs` is a stand-in EasyTime (`node dev/mock-easytime.mjs`, port
8088). Use it only if you change the code and want to check the logic before trying the real one.
Never point it at production ESS.
